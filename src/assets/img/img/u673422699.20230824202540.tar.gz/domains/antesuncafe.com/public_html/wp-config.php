<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u673422699_VuuMl' );

/** Database username */
define( 'DB_USER', 'u673422699_aRRne' );

/** Database password */
define( 'DB_PASSWORD', 'i0RG0enf5E' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          ':J{#P^8nWgPPjXbLwh$XuJ>6oKM7GE/2|M%z`VMaAvD*81k(2a65I][~A<n]*Flw' );
define( 'SECURE_AUTH_KEY',   '@,bFLl}qzCDyj96l@XZWZM^S#%`h bWIRz[Txl$=sGr$?>!glo;UX9Mhh7}#um78' );
define( 'LOGGED_IN_KEY',     'haZT!An1&E:lXzXN4oV%Zq?}Fds_ObT6$n7[uqKch@[occ S|ST?XI{KQ?3aFO,P' );
define( 'NONCE_KEY',         '2nnrT+F,V8R_4zYO/3JJjKXHE%oiZ FuCJX5us-RsjyQdcqH3wIng=>js:&%0DU|' );
define( 'AUTH_SALT',         'Q:Myb|z1/:KR#~}+h;qjQ/]MLK:KRc&[?g6_Sl~?,*yAt^oilO$F6dMwX)(e0h7r' );
define( 'SECURE_AUTH_SALT',  ']x7s8Uz%~~Y2d/IPQcI*GCw#=-*~:/*nNMwq7)+xL-xVq)_W!#8,-[q:69@K=oOe' );
define( 'LOGGED_IN_SALT',    'K~YOx}P)?AW(y_E)V8YzF2<BFZ4.%mQmA<y1~3t92q3y@wngaMK<u:)$5TH/CNe3' );
define( 'NONCE_SALT',        'B0g3?Asyy1w}t!Du>rTi,*[PeibehFx4A`OrI^8f{sc7rP#VgnrWG+L_rdKWv:9k' );
define( 'WP_CACHE_KEY_SALT', '<a9D-=[/FPV)id&8t-%Iw3{v|F=dr:#W~VX?i]M||6vE<ci|VnK ji `x(!%j9po' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



define( 'FS_METHOD', 'direct' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
